<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class AudioProject extends Model
{
    use HasFactory;

    
    public static $snakeAttributes = FALSE;
    public $timestamps  = FALSE;

    protected $fillable = ['user_id','project_title','project_file','path','status','created_at','updated_at','deleted_at'];

    public function audio_segment()
    {
        return $this->hasMany("App\Models\AudioProjectSplitPart", "project_id", "id");
    }

    public function getProjectFileAttribute($value){
        if(!empty($value)){
            return asset('public/project_upload').'/'.$value;
        }

        return $value;
    }

}
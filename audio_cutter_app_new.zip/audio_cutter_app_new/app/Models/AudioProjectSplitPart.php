<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AudioProjectSplitPart extends Model
{
    use HasFactory;

    
    public static $snakeAttributes = FALSE;
    public $timestamps  = FALSE;

    protected $fillable = ['user_id','project_id','audio_split_file','title','path','status','created_at','updated_at','deleted_at','start_time','end_time','duration'];

    public function getAudioSplitFileAttribute($value){
        if(!empty($value)){
            return asset('public/splitAudio').'/'.$this->path.'/'.$value;
        }
        
        return $value;
    }

}
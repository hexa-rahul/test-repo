<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\AudioProjectSplitPart;
use App\Models\AudioProject;

use Illuminate\Support\Facades\Storage;

class AudiocutterController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        // return view('audio_cutter');
        return view('test-audio-cutter');
    }

    public function splitAudio(Request $request){

        // validation
        $request->validate([
            'duration'  => 'required',
        //    'audioFile' =>'nullable|file|mimes:audio/mpeg,mpga,mp3,wav,aac'
        ]);
        
        if ($_FILES['audioFile']['error'] === UPLOAD_ERR_OK) {
            //
        }
        
        $duration     = $request->duration;

        if(!empty($request->file('audioFile'))) {
            
            $origanal_file = $request->file('audioFile')->getClientOriginalName();

            $project_name    = str_replace(".mp3"," ",$origanal_file);
            $project_name_uc = ucfirst($project_name);

            $timestam     = time();
            $fileName     = $timestam.'.'.$request->file('audioFile')->extension();  

            $request->file('audioFile')->move(public_path('/project_upload/'), $fileName);
            //Save Data
            $project_data     = array();
            $projrct_data['project_title'] = $project_name_uc;
            $projrct_data['project_file']  = $fileName;
            $projrct_data['path']          = $timestam;
            //Insert project
            $pData          = AudioProject::create($projrct_data);
            $project_id     = $pData->id;
            //Insert Split Audio
            
            //Split the file
            $split_file     = $timestam.'%03d.mp3';
            
            if (!file_exists(public_path('splitAudio').'/'.$timestam)) {
                mkdir(public_path('splitAudio').'/'.$timestam, 0777, true);
            }

            $outputPath     = public_path('project_output').'/'.$split_file;
            $targetPath     = asset('public/project_upload').'/'.$fileName;
            $cmd            = 'ffmpeg -i '.$targetPath.' -f segment -segment_time '.$duration.' -c copy '.$outputPath;
            $output         = shell_exec($cmd);

            //Output Dynamic Path

            $splitoutputPath     = public_path('splitAudio').'/'.$timestam.'/'.$split_file;
            $splitcmd            = 'ffmpeg -i '.$targetPath.' -f segment -segment_time '.$duration.' -c copy '.$splitoutputPath;
            $splitoutput         = shell_exec($splitcmd);

            
            $audiosplitoutputPath = public_path('splitAudio').'/'.$timestam;
            $downloadoutputPath   = asset('public/splitAudio').'/'.$timestam;
            
            // Count the number of output files created (number of segments)  02
            $segmentCount = count(glob($audiosplitoutputPath . '/'.$timestam.'*.mp3'));

            for ($i = 1; $i <= $segmentCount; $i++) {
                $_seg        = $i-1;
                $outputfile  = $timestam.'000'+$_seg;
                $segmentPath = $downloadoutputPath.'/'.$outputfile.'.mp3';
                $split_data  = array(
                                    'project_id'       => $project_id,
                                    'audio_split_file' => $outputfile.'.mp3',
                                    'title'            => $project_name_uc.'#'.$i,
                                    'path'             => $timestam
                                );

                AudioProjectSplitPart::create($split_data);

                //echo "<a href='$segmentPath'>Chapter#".$i."</a><br>";
            }


            return redirect(route('splitaudiolist'));

        }

        return $request->all();
    }

    public function splitAudioList(Request $request){

        $data = AudioProject::with('audio_segment')->latest()->get();
        return view('audio_cutter/split_list')->with(compact('data'));

    }

    public function splitWithStartAndEnd(Request $request){

        // Input audio file path
        $inputFile = asset('public/project_upload').'/1690191608000.mp3';

        // Output audio file path
        $outputFile = public_path('splitAudio').'/trimmed_audio.mp3';

        // Start time in seconds
        $startTime = 10; // Replace with the desired start time in seconds

        // End time in seconds
        $endTime   = 15; // Replace with the desired end time in seconds

        // FFmpeg command
        $ffmpegCmd = "ffmpeg -ss {$startTime} -i {$inputFile} -to {$endTime} -c copy {$outputFile} 2>&1";

        // Execute the FFmpeg command
        exec($ffmpegCmd, $output, $returnCode);

        // Check if the command was successful
        if ($returnCode === 0) {
            echo "Audio trimmed successfully.";
        } else {
            echo "Error trimming audio: " . implode("\n", $output);
        }

    }

    public function splitAudioWithTimeDuration(Request $request){

        // validation
        $request->validate([
        //    'duration'  => 'required',
            'audioFile' =>'nullable|file|mimes:audio/mpeg,mpga,mp3,wav,aac'
        ]);
        
        if ($_FILES['audioFile']['error'] === UPLOAD_ERR_OK) {
            //
        }
        
        $duration       = $request->duration;
        $start_time     = $request->start_time;
        $end_time       = $request->end_time;
        $time_duration  = $request->time_duration;

        // return $request; 
        //$new_time = date('H:i', strtotime('+15 minutes'));

        //echo $new_time; die;
        if(!empty($request->file('audioFile'))) {
            
            $origanal_file    = $request->file('audioFile')->getClientOriginalName();
            $removeWhiteSpace = str_replace(" ","", $origanal_file);

            $project_name     = str_replace(".mp3"," ",$origanal_file);
            $project_name_uc  = ucfirst($project_name);

            $res = str_replace( array( '\'', '"',',' , ';', '<', '>' ), '', $project_name);
            
            $removeWhiteSpace     = str_replace( [",", "<", ">", "!", "(", ")"], "", $removeWhiteSpace);

            $res     = str_replace([",", "<", ">", "!", "(", ")"],"",$res);
            


            // $timestam     = time();
            $timestam     = $project_name;
            $fileName     = $request->file('audioFile')->extension();  
            //$upload_path  = str_replace(" ","_",$project_name);
            $upload_path  = str_replace(" ","",$res);

            $isDirectory  = AudioProject::where('path', $upload_path)->count();
            if($isDirectory>0){
                return redirect()->back()->with('error', 'This audio file is already exist, please rename file name and upload again.');
            }

            $request->file('audioFile')->move(public_path('/project_upload/'), $removeWhiteSpace);
            //Save Data
            $project_data     = array();
            $projrct_data['project_title'] = $project_name_uc;
            $projrct_data['project_file']  = $removeWhiteSpace;
            $projrct_data['path']          = $upload_path;
            //Insert project
            $pData          = AudioProject::create($projrct_data);
            $project_id     = $pData->id;
            //Insert Split Audio
            
            //Split the file
            
            
            if (!file_exists(public_path('splitAudio').'/'.$upload_path)) {
                mkdir(public_path('splitAudio').'/'.$upload_path, 0777, true);
            }


            $segmentCount  = count($request->start_time); 
            
            for ($i = 0; $i < $segmentCount; $i++) {
                
                // Input audio file path
                $inputFile = asset('public/project_upload').'/'.$removeWhiteSpace;

                // Output audio file path
                $outputFile = public_path('splitAudio/').'/'.$upload_path.'/'.$upload_path.$i.'.mp3';
                //return $outputFile;
                // Start time in seconds
                // $startTime = $start_time[$i]; // Replace with the desired start time in seconds
                $startTime = $start_time[$i];
                
                $_st       = explode(":",$startTime);
                
                $_sth      = $_st[0]*60*60;
                $_stm      = $_st[1]*60;
                $_sts      = $_st[2];
                
                $startTimeInsecond = $_sth+$_stm+$_sts;

                // End time in seconds
                // $endTime = $request->end_time[$i]; // Replace with the desired end time in seconds

                $endTime = $end_time[$i];

                $_et       = explode(":",$endTime);
                
                $_eth      = $_et[0]*60*60;
                $_etm      = $_et[1]*60;
                $_ets      = $_et[2];
                
                $endTimeInSecond = $_eth+$_etm+$_ets;


                $audioTimeDuration = $endTimeInSecond-$startTimeInsecond;
                
                $timeDuration      =  $time_duration[$i];

                // FFmpeg command
                $ffmpegCmd = "ffmpeg -ss {$startTimeInsecond} -i {$inputFile} -to {$audioTimeDuration} -c copy {$outputFile} 2>&1";

                // Execute the FFmpeg command
                exec($ffmpegCmd, $output, $returnCode);

                $no          = 1;
                $chapter_sn  = $i+$no;

                // $ffmpegCommand = "ffmpeg -i {$inputFile} -ss {$startTimeInsecond} -to {$audioTimeDuration} -c copy {$outputFile}";
                // exec($ffmpegCommand);

                
                //$outputfile  = $fileName;
                
                $split_data  = array(
                                    'project_id'       => $project_id,
                                    'audio_split_file' => $upload_path.$i.'.mp3',
                                    'title'            => $project_name.'#'.$chapter_sn,
                                    'path'             => $upload_path,
                                    'start_time'       => $startTime,
                                    'end_time'         => $endTime,
                                    'duration'         => $timeDuration,
                                );

                AudioProjectSplitPart::create($split_data);

                //echo "<a href='$segmentPath'>Chapter#".$i."</a><br>";
            }

            return redirect(route('splitaudiolist'));

        }

    }

    public function calculateDuration(Request $request)
    {
        $startTime = $request->input('startTime');
        $stopTime  = $request->input('stopTime');

        // Calculate the duration using the same logic as in the previous PHP example
        $startTimeInSeconds = strtotime($startTime);
        $stopTimeInSeconds  = strtotime($stopTime);
        $timeDifferenceInSeconds = $stopTimeInSeconds - $startTimeInSeconds;

        $hours   = floor($timeDifferenceInSeconds / 3600);
        $minutes = floor(($timeDifferenceInSeconds % 3600) / 60);
        $seconds = $timeDifferenceInSeconds % 60;

        $formattedDuration = sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);

        // Return the result as a JSON response
        return response()->json(array("success" => true, "duration" => $formattedDuration));
    }

    public function editAudioView(Request $request, $id){
        
        $audio_project_id = decrypt($id); 
        $data  = AudioProject::where('id', $audio_project_id)->with('audio_segment')->first();

        return view('audio_cutter/edit-audio')->with(compact('data'));
    }
      
    public function editAudioWithSplit_oldCopy(Request $request){

        // validation
        $request->validate([
            'audioFile' =>'nullable|file|mimes:audio/mpeg,mpga,mp3,wav,aac'
        ]);
        
        if ($_FILES['audioFile']['error'] === UPLOAD_ERR_OK) {
            //
        }
        
        $audio_project_id = decrypt($request->audio_project_id); 
        $isAudioData      = AudioProject::where('id', $audio_project_id)->count();
        if($isAudioData==0){
        }

        $audioData        = AudioProject::where('id', $audio_project_id)->with('audio_segment')->first();
        

        if(!empty($request->file('audioFile'))) {
            
            $origanal_file    = $request->file('audioFile')->getClientOriginalName();
            $removeWhiteSpace = str_replace(" ","", $origanal_file);

            $project_name     = str_replace(".mp3"," ",$origanal_file);
            $project_name_uc  = ucfirst($project_name);

            $res = str_replace( array( '\'', '"',',' , ';', '<', '>' ), '', $project_name);
            

            $removeWhiteSpace     = str_replace( [",", "<", ">", "!", "(", ")"], "", $removeWhiteSpace);

            $res     = str_replace([",", "<", ">", "!", "(", ")"],"",$res);

            // $timestam     = time();
            $timestam     = $project_name;
            $fileName     = $request->file('audioFile')->extension();  
            //$upload_path  = str_replace(" ","_",$project_name);
            $upload_path  = str_replace(" ","",$res);

            $request->file('audioFile')->move(public_path('/project_upload/'), $removeWhiteSpace);
            //Save Data
            
           

            $audioData['project_title'] = $project_name_uc;
            $audioData['project_file']  = $removeWhiteSpace;
            $audioData['path']          = $upload_path;
            $audioData->save();

            if (!file_exists(public_path('splitAudio').'/'.$upload_path)) {
                mkdir(public_path('splitAudio').'/'.$upload_path, 0777, true);
            }


            $segmentCount  = $audioData->audio_segment->count(); 
            $audioSegment  = $audioData->audio_segment;
            AudioProjectSplitPart::where('project_id', $audio_project_id)->delete();

            foreach ($audioSegment as $segkey => $segvalue) {
                // Input audio file path
                $inputFile = asset('public/project_upload').'/'.$removeWhiteSpace;
                


                // Output audio file path
                $outputFile = public_path('splitAudio/').'/'.$upload_path.'/'.$upload_path.$segkey.'.mp3';
                
                $startTime = $segvalue->start_time;
                
                $_st       = explode(":",$startTime);
                
                $_sth      = $_st[0]*60*60;
                $_stm      = $_st[1]*60;
                $_sts      = $_st[2];
                
                $startTimeInsecond = $_sth+$_stm+$_sts;

                $endTime = $segvalue->end_time;

                $_et       = explode(":",$endTime);
                
                $_eth      = $_et[0]*60*60;
                $_etm      = $_et[1]*60;
                $_ets      = $_et[2];
                
                $endTimeInSecond = $_eth+$_etm+$_ets;


                $audioTimeDuration = $endTimeInSecond-$startTimeInsecond;

                // FFmpeg command
                $ffmpegCmd = "ffmpeg -ss {$startTimeInsecond} -i {$inputFile} -to {$audioTimeDuration} -c copy {$outputFile} 2>&1";

                // Execute the FFmpeg command
                exec($ffmpegCmd, $output, $returnCode);

                $split_data  = array(
                                    'project_id'       => $audio_project_id,
                                    'audio_split_file' => $upload_path.$segkey.'.mp3',
                                    'title'            => $project_name.'#'.$segkey,
                                    'path'             => $upload_path,
                                    'start_time'       => $startTime,
                                    'end_time'         => $endTime,
                                );

                AudioProjectSplitPart::create($split_data);
            }

            return redirect(route('splitaudiolist'));

        }

    }

    public function editAudioWithSplit(Request $request){

        // validation
        $request->validate([
            'audioFile' =>'nullable|file|mimes:audio/mpeg,mpga,mp3,wav,aac'
        ]);
        
        if ($_FILES['audioFile']['error'] === UPLOAD_ERR_OK) {
            //
        }
        
        $audio_project_id = decrypt($request->audio_project_id); 
        $isAudioData      = AudioProject::where('id', $audio_project_id)->count();
        if($isAudioData==0){
        }

        $audioData        = AudioProject::where('id', $audio_project_id)->with('audio_segment')->first();
        

        if(!empty($request->file('audioFile'))) {
            
            $origanal_file    = $request->file('audioFile')->getClientOriginalName();
            $removeWhiteSpace = str_replace(" ","", $origanal_file);

            $project_name     = str_replace(".mp3"," ",$origanal_file);
            $project_name_uc  = ucfirst($project_name);

            $res = str_replace( array( '\'', '"',',' , ';', '<', '>' ), '', $project_name);
            
            $removeWhiteSpace = str_replace( [",", "<", ">", "!", "(", ")"], "", $removeWhiteSpace);
            $res              = str_replace([",", "<", ">", "!", "(", ")"],"",$res);


            // $timestam     = time();
            $timestam     = $project_name;
            $fileName     = $request->file('audioFile')->extension();  
            //$upload_path  = str_replace(" ","_",$project_name);
            $upload_path  = str_replace(" ","",$res);

            $request->file('audioFile')->move(public_path('/project_upload/'), $removeWhiteSpace);
            //Save Data
            
            $audioData['project_title'] = $project_name_uc;
            $audioData['project_file']  = $removeWhiteSpace;
            $audioData['path']          = $upload_path;
            $audioData->save();

        }else{
            
            $upload_path  = $audioData->path;
            $project_name = $audioData->project_title;
            $upload_path  = $audioData->path;
        }
        

        $existAudioPath = $audioData->project_file;
        $dirname        = public_path('splitAudio/').'/'.$audioData->path;
        $isPath         = realpath($dirname);

        if($isPath !== false AND is_dir($isPath))
        {
            array_map('unlink', glob("$dirname/*.*")); 
            rmdir($dirname);
        }

        if (!file_exists($dirname)) {
            mkdir($dirname, 0777, true);
        }

        //Update Segment
        $segmentCount   = $audioData->audio_segment->count(); 
        $audioSegment   = $audioData->audio_segment;
        AudioProjectSplitPart::where('project_id', $audio_project_id)->delete();
        
        $start_time     = $request->start_time;
        $end_time       = $request->end_time;
        $time_duration  = $request->time_duration;
        $segmentCount   = count($request->start_time); 
            

        for ($i = 0; $i < $segmentCount; $i++) {
            
            // Input audio file path
            $inputFile = $existAudioPath;

            // Output audio file path
            $outputFile = $dirname.'/'.$upload_path.$i.'.mp3';
            
            // Start time in seconds
            $startTime = $start_time[$i];
            
            $_st       = explode(":",$startTime);
            $_sth      = $_st[0]*60*60;
            $_stm      = $_st[1]*60;
            $_sts      = $_st[2];
            
            $startTimeInsecond = $_sth+$_stm+$_sts;

            // End time in seconds
            $endTime = $end_time[$i];

            $_et       = explode(":",$endTime);
            $_eth      = $_et[0]*60*60;
            $_etm      = $_et[1]*60;
            $_ets      = $_et[2];
            
            $endTimeInSecond   = $_eth+$_etm+$_ets;
            $audioTimeDuration = $endTimeInSecond-$startTimeInsecond;
            $timeDuration      =  $time_duration[$i];

            // FFmpeg command
            $ffmpegCmd = "ffmpeg -ss {$startTimeInsecond} -i {$inputFile} -to {$audioTimeDuration} -c copy {$outputFile} 2>&1";

            // Execute the FFmpeg command
            exec($ffmpegCmd, $output, $returnCode);
            $no          = 1;
            $chapter_sn  = $i+$no;

            $split_data  = array(
                                'project_id'       => $audio_project_id,
                                'audio_split_file' => $upload_path.$i.'.mp3',
                                'title'            => $project_name.'#'.$chapter_sn,
                                'path'             => $upload_path,
                                'start_time'       => $startTime,
                                'end_time'         => $endTime,
                                'duration'         => $timeDuration,
                            );

            AudioProjectSplitPart::create($split_data);

        }

        return redirect(route('splitaudiolist'));

    }

}

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="{{ asset('public/assets/style.css') }}">
</head>
<body>
<div class="container-fluid" style="margin-top: 10px;">
	<div class="container">
		<div class="container-section">
			<div class="row_header">
				<a href="{{ route('audioform') }}" class="btn btn-info" style="float: right;">Add New Project</a>
			</div>
			
			<h2 style="margin-bottom: 25px">All Projects </h2>
			<div class="tab">
			  @if($data->count()>0)	
			  	@foreach($data as $key => $menu_value)
				  <button class="tablinks" onclick="openCity(event, 'opentab_{{ $key }}')" @if($key==0) id="defaultOpen" @endif>{{ $menu_value->project_title }}</button>
				@endforeach
			  @endif
			</div>
      @if($data->count()>0)	
		  @foreach($data as $key => $tab_value)
			<div id="opentab_{{ $key }}" class="tabcontent" >
			  	<h3 style="margin-bottom: 25px">{{ $tab_value->project_title }}</h3>
			  	<audio controls>
				  	<source src="{{ $tab_value->project_file }}" type="audio/ogg">
				  	<source src="{{ $tab_value->project_file }}" type="audio/mpeg">
					  Your browser does not support the audio element.
					</audio>

				<a href="{{ route('downloadzip', encrypt($tab_value->path)) }}" class="btn btn-default" style="float:right">
					<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-download" viewBox="0 0 16 16">
  				<path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/>
  				<path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"/>
					</svg> Download All
				</a>

				<a href="{{ route('editaudioview', encrypt($tab_value->id)) }}" class="btn btn-info" style="float:right;margin-right: 5px;">
					<i class="fa fa-edit"></i> Edit
				</a>

				<div class="mt-10" style="margin-top:35px; border-top:1px solid grey">
					<h3>{{ $tab_value->project_title }} all chapters</h3>
				</div>
				<div class="mt-10">
					<table class="table">
						<tr>
							<th>SN</th>
							<th>#</th>
							<th>Title</th>
							<th>Start time</th>
							<th>End Time</th>
						</tr>
						@foreach($tab_value->audio_segment as $seg_key => $seg_value)
						<tr>
							<td><span class="spliter_sn">{{ $seg_key+1 }}</span></td>
							<td>
								<audio controls>
							  	<source src="{{ $seg_value->audio_split_file }}" type="audio/ogg">
							  	<source src="{{ $seg_value->audio_split_file }}" type="audio/mpeg">
								  Your browser does not support the audio element.
							</audio>
							</td>
							<td>{{ $seg_value->title }}</td>
							<td>{{ $seg_value->start_time }}</td>
							<td>{{ $seg_value->end_time }}</td>
						</tr>
						@endforeach
					</table>
					
    				
				</div>
			</div>
			@endforeach
		  @endif
		</div>
	</div>
</div>


<script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";

  //   $('audio').each(function(){
		//     this.pause(); // Stop playing
		//     this.currentTime = 0; // Reset time
		// });
  }
  
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  
  //$("audio").pause();
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>

<script type="text/javascript">
	$("audio").bind("play",function (){
	  $("audio").not(this).each(function (index, audio) {
	    audio.pause();
	  });
	});
</script>
   
</body>
</html>
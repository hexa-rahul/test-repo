<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="{{ csrf_token() }}">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="{{ url('public') }}/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
<script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<style>
* {box-sizing: border-box}
body {font-family: "Lato", sans-serif;}

/* Style the tab */
.tab {
  float: left;
  /*border: 1px solid #ccc;*/
  /*background-color: #f1f1f1;*/
  width: 30%;
  /*height: 300px;*/
  height: auto;
}

/* Style the buttons inside the tab */
.tab button {
  display: block;
  background-color: #f0f0f0;
  color: black;
  padding: 22px 16px;
  width: 100%;
  border: none;
  outline: none;
  text-align: left;
  cursor: pointer;
  transition: 0.3s;
  font-size: 17px;
  border-radius: 8px;
  margin-bottom: 1px;
  border-bottom: 1px solid lightgrey;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current "tab button" class */
.tab button.active {
  background-color: #f0f0f0;
  border: 1px solid darkgrey;
  border-radius: 8px;
}

.btn-primary {
    color: black;
    background-color: #f0f0f0;
    border-color: lightgray;
}

/* Style the tab content */
.tabcontent {
  float: left;
  padding: 10px 12px;
  /*border: 1px solid #ccc;*/
  width: 70%;
  border-left: none;
  /*height: 300px;*/
  height: auto;
}
.row_header {
    padding: 4% 2%;
    border-bottom: 1px solid grey;
    margin-bottom: 12px;
}
body{
	background-color: #f7f7f7;
	/*font-family: monospace;*/
}
.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
      padding: 10px;
      line-height: 1.5;
      vertical-align: top;
      border-top: 1px solid #ddd;
      /*font-family: monospace;*/
      padding-top: 12px;
      font-size: 17px;
  }
  .h3, h3 {
	    font-size: 19px;
	    font-weight: 400;
	    color: dodgerblue;
	}

</style>
</head>
<body>
<div class="container-fluid" style="margin-top: 50px;">
	<div class="container">
		<div class="container-section">
			<form action="{{ route('editaudio') }}" method="post" enctype="multipart/form-data" style="margin-bottom: 60px;">
      	@csrf
      	<fieldset>
      		<legend>Update Audio File: </legend>
        	<div class="form-group mb-3.">
		      	<label for="exampleInputEmail1" class="form-label mt-4">Choose Audio file</label>
		        <input type="file" class="form-control" name="audioFile" id="exampleInputaudio" accept=".mp3" aria-describedby="audioHelp" placeholder="Enter choose sudio file" required="true">

		        <input type="hidden" name="audio_project_id" value="{{ encrypt($data->id) }}">
		        @error('audioFile')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
            @enderror

		    	</div>
        	<div class="form-group mt-5." style="margin-top: 20px">
				    	<button type="submit" class="btn btn-info">Submit</button>
					</div>
				</fieldset>
      </form>
			<div id="opentab_1" class="tabcontent" style="width:85%;margin: auto;">
			  	
          <h3 style="margin-bottom: 25px">{{ $data->project_title }}</h3>
			  	<audio controls>
				  	<source src="{{ $data->project_file }}" type="audio/ogg">
				  	<source src="{{ $data->project_file }}" type="audio/mpeg">
					  Your browser does not support the audio element.
					</audio>

				<div class="mt-10" style="margin-top:35px; border-top:1px solid grey">
					<h3>{{ $data->project_title }} all chapters</h3>
				</div>
				<div class="mt-10">
					<table class="table">
						<tr>
							<th>#</th>
							<th>Title</th>
							<th>Start time</th>
							<th>End Time</th>
						</tr>
						@foreach($data->audio_segment as $seg_key => $seg_value)
						<tr>
							<td>
								<audio controls>
							  	<source src="{{ $seg_value->audio_split_file }}" type="audio/ogg">
							  	<source src="{{ $seg_value->audio_split_file }}" type="audio/mpeg">
								  Your browser does not support the audio element.
							</audio>
							</td>
							<td>{{ $seg_value->title }}</td>
							<td>{{ $seg_value->start_time }}</td>
							<td>{{ $seg_value->end_time }}</td>
						</tr>
						@endforeach
					</table>
					
    				
				</div>
			</div>
			
		</div>
	</div>
</div>


<script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";

  //   $('audio').each(function(){
		//     this.pause(); // Stop playing
		//     this.currentTime = 0; // Reset time
		// });
  }
  
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  
  //$("audio").pause();
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>

<script type="text/javascript">
	$("audio").bind("play",function (){
	  $("audio").not(this).each(function (index, audio) {
	    audio.pause();
	  });
	});
</script>
   
</body>
</html>
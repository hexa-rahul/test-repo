<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ZipController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Auth::routes();

// Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');


Route::get('/split-audio-add', [App\Http\Controllers\AudiocutterController::class, 'index'])->name('audioform');

Route::post('/split-audio', [App\Http\Controllers\AudiocutterController::class, 'splitAudio'])->name('splitaudio');

Route::get('/', [App\Http\Controllers\AudiocutterController::class, 'splitAudioList'])->name('splitaudiolist');

Route::get('download-zip/{path}', ZipController::class)->name('downloadzip');


Route::get('/split-start-end', [App\Http\Controllers\AudiocutterController::class, 'splitWithStartAndEnd'])->name('splitstartend');

Route::post('/audio-partition', [App\Http\Controllers\AudiocutterController::class, 'splitAudioWithTimeDuration'])->name('audiopartition');

Route::post('/calculate-duration', [App\Http\Controllers\AudiocutterController::class, 'calculateDuration'])->name('calculateduration');

Route::get('/edit-audio-view/{id}', [App\Http\Controllers\AudiocutterController::class, 'editAudioView'])->name('editaudioview');

Route::post('/edit-audio', [App\Http\Controllers\AudiocutterController::class, 'editAudioWithSplit'])->name('editaudio');



//For testing
Route::get('/test-split-audio-add', [App\Http\Controllers\AudiocutterController::class, 'index']);

Route::get('/test-form', function () {
    return view('test-audio-cutter');
});

Route::get('/parsing-json', [App\Http\Controllers\AudiocutterController::class, 'parsingJson']);







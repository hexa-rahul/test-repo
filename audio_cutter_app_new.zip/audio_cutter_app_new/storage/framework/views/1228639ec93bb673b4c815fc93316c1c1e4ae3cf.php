<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Audio Cutter</title>
	<link rel="stylesheet" type="text/css" href="bootstrap.min.css">
</head>
<body>
	<div class="container">
		<form action="<?php echo e(route('splitaudio')); ?>" method="post" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
		  	<fieldset>
			    
			    <legend>Upload Audio File: </legend>
			    
			    <div class="form-group mb-3.">
			      	<label for="exampleInputEmail1" class="form-label mt-4">Choose Audio file</label>
			        <input type="file" class="form-control" name="audioFile" id="exampleInputaudio" aria-describedby="audioHelp" placeholder="Enter choose sudio file">
			        <?php $__errorArgs = ['audioFile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			    </div>

			    <div class="form-group">
			      	<label for="exampleInputduration" class="form-label mt-4">Duration<small>(In Second)</small></label>
			      	<input type="number" class="form-control" name="duration" id="exampleInputduration" placeholder="Enter audio split duration">
			      	<?php $__errorArgs = ['duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			    </div>

			    <div class="form-group mt-5." style="margin-top: 20px">
			    	<button type="submit" class="btn btn-primary">Submit</button>
				</div>
		    </fieldset>
		</form>
	</div>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/audio_cutter_app/resources/views/audio_cutter.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Audio Cutter</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('public')); ?>/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/style.css')); ?>">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>
	<div class="container">
        <div class="form-group mt-5." style="margin-top: 20px;margin-bottom: 20px;text-align: right;">
            <a href="<?php echo e(route('splitaudiolist')); ?>" class="btn btn-primary btn-theme">Go to back</a>
        </div>
        <div class="col-sm-12">
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show mt-10" role="alert">
                <?php echo e(Session::get('success')); ?>

                <?php
                    Session::forget('success');
                ?>
            </div>
            <?php elseif(Session::has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show mt-10" role="alert">
                <?php echo e(Session::get('error')); ?>

                <?php
                    Session::forget('error');
                ?>
            </div>
            <?php endif; ?>
        </div>
		<form action="<?php echo e(route('audiopartition')); ?>" method="post" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
		  	<fieldset>
			    <h2 style="margin-bottom: 25px">Upload Audio File: </h2>
			    <!-- <legend>Upload Audio File: </legend> -->
			    
			    <div class="form-group mb-3. col-sm-5">
			      	<label for="exampleInputEmail1" class="form-label mt-4">Choose Audio file</label>
			        <input type="file" class="form-control" name="audioFile" id="exampleInputaudio" accept=".mp3" aria-describedby="audioHelp" placeholder="Enter choose sudio file" required="true">
			        <?php $__errorArgs = ['audioFile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			    </div>

			    <div class="form-group" style="display: none;">
			      	<label for="exampleInputduration" class="form-label mt-4">Duration<small>(In Second)</small></label>
			      	<input type="number" class="form-control" name="duration" id="duration" placeholder="Enter audio split duration">
			      	<?php $__errorArgs = ['duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			    </div>

			    <div class="form-group add_more_button">
			    	<button id="rowAdder" type="button" class="btn btn-dark">
                        <span class="bi bi-plus-square-dotted">
                        </span> Add More Audio Partition
                    </button>
			    </div>

			    <div class="">
                <div class="col-lg-12">
                    <div id="row">
                        <div class="input-group mt-3">
                            <!-- <span class="spliter_sn">01</span> -->
                            <span class="spliter_sn">1</span>
                            <input type="text" class="form-control m-input duration_format" name="start_time[]" id="startTimeDuration_1" style="margin-right:5px" placeholder="00:00:00" onchange="calculateTimeDuration(1)" step="1" pattern="^(?:[0-9]{2}:){2}[0-9]{2}$" required="true"/>
                            <input type="text" class="form-control m-input duration_format" name="end_time[]" id="endTimeDuration_1" style="margin-left:5px" placeholder="00:00:00" onchange="calculateTimeDuration(1)" pattern="^(?:[0-9]{2}:){2}[0-9]{2}$" required="true">
                            <input type="text" class="form-control m-input" name="time_duration[]" id="time_duration_1" style="margin-left:5px" placeholder="00:00:00" readonly="true">
                            <div class="input-group-prepend">
                                <button class="btn btn-danger"
                                        id="DeleteRow"
                                        type="button">
                                    <i class="bi bi-trash"></i>
                                    Delete
                                </button>
                            </div>
                        </div>
                    </div>
 
                    <div id="newinput"></div>
                    
                </div>
            </div>

			    <div class="form-group mt-5." style="margin-top: 20px">
			    	<button type="submit" class="btn btn-primary  btn-theme">Submit</button>
				</div>
		    </fieldset>
		</form>
        <!-- <div id="result"></div>
		<button id="calculateDurationBtn">check</button> -->
	</div>

	<script type="text/javascript">
        var row_count = 1;
        var rowDelete = 1;

        $("#rowAdder").click(function () {
            row_count++;
            rowDelete++;
            var snNumber =  ('0' + row_count).slice(-2);
            
            newRowAdd =
                '<div id="row"> <div class="input-group mt-3">' +
                '<span class="spliter_sn">'+row_count+'</span><input type="text" class="form-control m-input duration_format" name="start_time[]" id="startTimeDuration_'+row_count+'" onchange="calculateTimeDuration('+row_count+')" style="margin-right:5px" placeholder="00:00:00" pattern="^(?:[0-9]{2}:){2}[0-9]{2}$" required="true"/><input type="text" class="form-control m-input duration_format" name="end_time[]" id="endTimeDuration_'+row_count+'" onchange="calculateTimeDuration('+row_count+')" style="margin-left:5px" placeholder="00:00:00" pattern="^(?:[0-9]{2}:){2}[0-9]{2}$" required="true"><input type="text" class="form-control m-input" name="time_duration[]" id="time_duration_'+row_count+'" style="margin-left:5px" placeholder="00:00:00" readonly="true"><div class="input-group-prepend">' +
                '<button class="btn btn-danger" id="DeleteRow" type="button">' +
                '<i class="bi bi-trash"></i> Delete</button> </div>' +
                '</div> </div>';
 
            $('#newinput').append(newRowAdd);
        });
        $("body").on("click", "#DeleteRow", function () {
            
            if(rowDelete==1){
                alert('At least 1 partition should be there.');
                return false;
            }
            rowDelete--;
            $(this).parents("#row").remove();
        })
    </script>

    <script>
    const durationInput = getElementsByClassName("duration_format");

        durationInput.addEventListener("input", function () {
          // Validate the input format while typing
          const validFormat = /^(?:[0-9]{2}:){2}[0-9]{2}$/.test(durationInput.value);
          durationInput.setCustomValidity(validFormat ? "" : "Invalid time duration format (hh:mm:ss)");
        });

        // Optionally, you can handle the form submission and parse the duration value as needed.
        // For example, you can convert the duration to seconds for further processing.
    </script>

    <script>
        function calculateTimeDuration(id){
            
                
             var startTime = $("#startTimeDuration_"+id).val();
             var stopTime  = $("#endTimeDuration_"+id).val();
             
             if(stopTime==''){
                return true;
                exist();
             }
            //var startTime = '00:01:00';
            //var stopTime  = '00:10:00';
            
            // AJAX request to send the stopwatch timings to the server
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "<?php echo e(route('calculateduration')); ?>", // PHP script to handle the calculation
                data: { startTime: startTime, stopTime: stopTime },
                dataType: "json",
                success: function(response) {
                    if (response.success) {
                        //$("#result").text("Total duration: " + response.duration);
                        //$("#time_duration_"+id).val(response.duration);
                        $("#time_duration_"+id).attr("value", response.duration);

                    } else {
                        $("#result").text("Error occurred during calculation.");
                    }
                },
                error: function() {
                    $("#result").text("Error occurred during AJAX request.");
                }
            });
        }
            
    </script>

</body>
</html><?php /**PATH /var/www/html/audio_cutter_app/resources/views/test-audio-cutter.blade.php ENDPATH**/ ?>
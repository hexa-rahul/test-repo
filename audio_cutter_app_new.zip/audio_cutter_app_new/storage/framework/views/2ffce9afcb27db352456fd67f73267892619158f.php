<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="<?php echo e(asset('public/assets/style.css')); ?>">
</head>
<body>
<div class="container-fluid" style="margin-top: 10px;">
	<div class="container">
		<div class="container-section">
			<div class="row_header">
				<a href="<?php echo e(route('audioform')); ?>" class="btn btn-info" style="float: right;">Add New Project</a>
			</div>
			
			<h2 style="margin-bottom: 25px">All Projects </h2>
			<div class="tab">
			  <?php if($data->count()>0): ?>	
			  	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $menu_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				  <button class="tablinks" onclick="openCity(event, 'opentab_<?php echo e($key); ?>')" <?php if($key==0): ?> id="defaultOpen" <?php endif; ?>><?php echo e($menu_value->project_title); ?></button>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  <?php endif; ?>
			</div>
      <?php if($data->count()>0): ?>	
		  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tab_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div id="opentab_<?php echo e($key); ?>" class="tabcontent" >
			  	<h3 style="margin-bottom: 25px"><?php echo e($tab_value->project_title); ?></h3>
			  	<audio controls>
				  	<source src="<?php echo e($tab_value->project_file); ?>" type="audio/ogg">
				  	<source src="<?php echo e($tab_value->project_file); ?>" type="audio/mpeg">
					  Your browser does not support the audio element.
					</audio>

				<a href="<?php echo e(route('downloadzip', encrypt($tab_value->path))); ?>" class="btn btn-default" style="float:right">
					<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-download" viewBox="0 0 16 16">
  				<path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/>
  				<path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"/>
					</svg> Download All
				</a>

				<a href="<?php echo e(route('editaudioview', encrypt($tab_value->id))); ?>" class="btn btn-info" style="float:right;margin-right: 5px;">
					<i class="fa fa-edit"></i> Edit
				</a>

				<div class="mt-10" style="margin-top:35px; border-top:1px solid grey">
					<h3><?php echo e($tab_value->project_title); ?> all chapters</h3>
				</div>
				<div class="mt-10">
					<table class="table">
						<tr>
							<th>SN</th>
							<th>#</th>
							<th>Title</th>
							<th>Start time</th>
							<th>End Time</th>
						</tr>
						<?php $__currentLoopData = $tab_value->audio_segment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seg_key => $seg_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><span class="spliter_sn"><?php echo e($seg_key+1); ?></span></td>
							<td>
								<audio controls>
							  	<source src="<?php echo e($seg_value->audio_split_file); ?>" type="audio/ogg">
							  	<source src="<?php echo e($seg_value->audio_split_file); ?>" type="audio/mpeg">
								  Your browser does not support the audio element.
							</audio>
							</td>
							<td><?php echo e($seg_value->title); ?></td>
							<td><?php echo e($seg_value->start_time); ?></td>
							<td><?php echo e($seg_value->end_time); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</table>
					
    				
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  <?php endif; ?>
		</div>
	</div>
</div>


<script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";

  //   $('audio').each(function(){
		//     this.pause(); // Stop playing
		//     this.currentTime = 0; // Reset time
		// });
  }
  
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  
  //$("audio").pause();
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>

<script type="text/javascript">
	$("audio").bind("play",function (){
	  $("audio").not(this).each(function (index, audio) {
	    audio.pause();
	  });
	});
</script>
   
</body>
</html><?php /**PATH /var/www/html/audio_cutter_app/resources/views/audio_cutter/split_list.blade.php ENDPATH**/ ?>